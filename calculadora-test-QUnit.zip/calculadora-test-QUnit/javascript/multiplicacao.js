function fnMultiplicar(num1, num2){
    return num1 * num2;
}

module.exports = fnMultiplicar;