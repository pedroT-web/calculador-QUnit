function fnCalcula() {
    let numero1 = document.getElementById("primeiroNumero").value
    let numero2 = document.getElementById("segundoNumero").value
    let operacao = document.getElementById("operacao").value
    const resultadoFinal = document.getElementById("resultado")

    let num1 = parseFloat(numero1);
    let num2 = parseFloat(numero2);

    if (numero1 == "") {
        alert("Preencha o campo do primeiro número")
        return
    }
    if (numero2 == "") {
        alert("Preencha o campo do segundo número")
        return
    }

    switch (operacao) {
        case "soma":
            resultadoFinal.innerText = fnSoma(num1, num2);
            break;
        case "subtracao":
            resultadoFinal.innerText = fnSubtracao(num1, num2);
            break;
        case "multiplicacao":
            // alert("Hello")
            resultadoFinal.innerText = fnMultiplicar(num1, num2);
            break;
        case "divisao":
            if (num2 == 0) {
                alert("Não é possível dividir por zero!")
                return;
            }
            resultadoFinal.innerText = fnDividir(num1, num2);
            break;
        default:
            alert("Selecione uma operção");
    }

    fnValidarCor();

}