function fnSoma(num1, num2){
    return num1 + num2;
}

module.exports = fnSoma;