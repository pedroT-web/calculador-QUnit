function fnValidarCor(){
    let campoResultado = document.getElementById("resultado")
    let resultadoCalculo = parseFloat(campoResultado.innerText)
    
    if(resultadoCalculo < 0){
        campoResultado.style.color = "red";
    }else{
        campoResultado.style.color = "green";
    }
}