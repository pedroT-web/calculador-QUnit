const fnDividir = require("../javascript/divisao");

QUnit.module("fnDividir");

QUnit.test("Divisão de 10 por 10 = 1", (resultado)=>{
    resultado.equal(fnDividir(10, 10), 1)
})

QUnit.test("Divisão de 100 por 5 = 20", (resultado)=>{
    resultado.equal(fnDividir(100, 5), 20)
})

QUnit.test("Divisão de 99 por -3 = -33", (resultado)=>{
    resultado.equal(fnDividir(99, -3), -33)
})

QUnit.test("Divisão de 90 por 9 = 10", (resultado)=>{
    resultado.equal(fnDividir(90, 9), 10)
})