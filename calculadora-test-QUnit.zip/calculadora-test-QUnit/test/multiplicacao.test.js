const fnMultiplicar = require("../javascript/multiplicacao");

QUnit.module("fnMultiplicar");

QUnit.test("Multiplcação de 10 X 10 = 100", (resultado) => {
    resultado.equal(fnMultiplicar(10, 10), 100)
})

QUnit.test("Multiplicação de 100 X 100 = 10000", (resultado) =>{
    resultado.equal(fnMultiplicar(100, 100), 10000)
})

QUnit.test("Multiplicação de 9 X 9 = 81", (resultado)=>{
    resultado.equal(fnMultiplicar(9, 9), 81)
})

QUnit.test("Multiplicação de 8 X 8 = 64", (resultado)=>{
    resultado.equal(fnMultiplicar(8, 8), 64)
})