const fnSubtracao = require("../javascript/subtracao");

QUnit.module("fnSubtracao");

QUnit.test("Subtração de 19 - 2", (resultado) => {
    resultado.equal(fnSubtracao(19, 2), 17)
})

QUnit.test("Subtração de -8 -9 = 1", (resultado)=>{
    resultado.equal(fnSubtracao(-8, -9), 1)
})

QUnit.test("Subtração de 9 - 9 = 0", (resultado)=>{
    resultado.equal(fnSubtracao(9, 9), 0)
})

QUnit.test("Subtração de 0 - 0", (resultado)=>{
    resultado.equal(fnSubtracao(0, 0), 0)
})