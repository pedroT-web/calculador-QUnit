const fnSoma = require("../javascript/soma");

QUnit.module('fnSoma');

QUnit.test("Soma de 1 + 2 = 3", (resultado) => {
    resultado.equal(fnSoma(1, 2), 3);
});

QUnit.test("Soma de 10 + 99 = 109", (resultado) => {
    resultado.equal(fnSoma(10, 99), 109)
});

QUnit.test("Soma de 78 + -10 = 68", (resultado) => {
    resultado.equal(fnSoma(78, -10), 68)
})

QUnit.test("Soma de 99 + 1 = 100", (resultado) => {
    resultado.equal(fnSoma(99, 1), 100)
});